module.exports = function ({ models, api }) {
    const { readFileSync, writeFileSync } = require("fs-extra");
    var path = __dirname + "/data/usersData.json";

    try {
        var usersData = require(path)
    } catch {
        writeFileSync(path, "{}", { flag: 'a+' });
    }

    async function saveData(data) {
        try {
            if (!data) throw new Error('Data không được để trống');
            writeFileSync(path, JSON.stringify(data, null, 4))
            return true
        } catch (error) {
            return false
        }
    }

    async function getInfo(id) {
        return (await api.getUserInfo(id))[id];
    }

    async function getNameUser(userID) {
        try {
            if (!userID) throw new Error("ID người dùng không được để trống");
            if (isNaN(userID)) throw new Error("ID người dùng không hợp lệ");
            var userInfo = await api.getUserInfo(userID);
            return userInfo[userID].name;
        } catch (error) {
            return `Người dùng facebook`
        }
    }
    async function getUserFull(id) {
        var resolveFunc = function () { };
        var rejectFunc = function () { };
        var returnPromise = new Promise(function (resolve, reject) {
          resolveFunc = resolve;
          rejectFunc = reject;
        });
        try {
            api.httpGet(`https://graph.facebook.com/${id}?fields=name,email,about,birthday,gender,hometown,link,location,quotes,relationship_status,significant_other,username,subscribers.limite(0),website&access_token=${global.account.accessToken}`, (e, i) => {
                if (e) return rejectFunc(e)
                var t = JSON.parse(i);
                var dataUser = {
                    error: 0,
                    author: 'D-Jukie',
                    data: {
                        name: t.name || null,
                        username: t.username || null,
                        uid: t.id || null,
                        about: t.about || null,
                        follow: t.subscribers.summary.total_count || 0,
                        birthday: t.birthday || null,
                        gender: t.gender,
                        hometown: t.hometown || null,
                        link: t.link || null,
                        location: t.location || null,
                        relationship_status: t.relationship_status || null,
                        love: t.significant_other || null,
                        quotes: t.quotes || null,
                        website: t.website || null,
                        imgavt: `https://graph.facebook.com/${t.id}/picture?height=1500&width=1500&access_token=1073911769817594|aa417da57f9e260d1ac1ec4530b417de`
                    }
                };
                return resolveFunc(dataUser)
            });
            return returnPromise
        }
        catch(error) { 
            return resolveFunc({
                error: 1, 
                author: 'D-Jukie',
                data: {}
            })
        }
    }
    
    async function getAll(keys, callback) {
        try {
            if (!keys) {
                if (Object.keys(usersData).length == 0) return [];
                else if (Object.keys(usersData).length > 0) {
                    var db = [];
                    for (var i of Object.keys(usersData)) db.push(usersData[i]);
                    return db;
                }
            }
            if (!Array.isArray(keys)) throw new Error("Tham số truyền vào phải là 1 array");
            const data = [];
            for (var userID in usersData) {
                var database = {
                    ID: userID
                };
                var userData = usersData[userID];
                for (var i of keys) database[i] = userData[i];
                data.push(database);
            }
            if (callback && typeof callback == "function") callback(null, data);
            return data;
        } catch (error) {
            if (callback && typeof callback == "function") callback(error, null);
            return false
        }
    }

    async function getData(userID, callback) {
        try {
            if (!userID) throw new Error("ID người dùng không được để trống");
            if (isNaN(userID)) throw new Error("ID người dùng không hợp lệ");
            if (!usersData.hasOwnProperty(userID)) await createData(userID, (error, info) => {
                return info;
            });
            const data = usersData[userID];
            if (callback && typeof callback == "function") callback(null, data);
            return data;
        } catch (error) {
            if (callback && typeof callback == "function") callback(error, null);
            return false
        }
    }

    async function setData(userID, options, callback) {
        try {
            if (!userID) throw new Error("ID người dùng không được để trống");
            if (isNaN(userID)) throw new Error("ID người dùng không hợp lệ");
            if (!userID) throw new Error("userID không được để trống");
            if (!usersData.hasOwnProperty(userID)) throw new Error(`Người dùng mang ID: ${userID} không tồn tại trong Database`);
            if (typeof options != 'object') throw new Error("Tham số options truyền vào phải là 1 object");
            usersData[userID] = {...usersData[userID], ...options};
            await saveData(usersData);
            if (callback && typeof callback == "function") callback(null, dataUser[userID]);
            return usersData[userID];
        } catch (error) {
            if (callback && typeof callback == "function") callback(error, null);
            return false
        }
    }

    async function delData(userID, callback) {
        try {
            if (!userID) throw new Error("ID người dùng không được để trống");
            if (isNaN(userID)) throw new Error("ID người dùng không hợp lệ");
            if (!usersData.hasOwnProperty(userID)) throw new Error(`Người dùng mang ID: ${userID} không tồn tại trong Database`);
            delete usersData[userID];
            await saveData(usersData);
            if (callback && typeof callback == "function") callback(null, usersData);
            return usersData;
        } catch (error) {
            if (callback && typeof callback == "function") callback(error, null);
            return false
        }
    }

    async function createData(userID, callback) {
        try {
            if (!userID) throw new Error("ID người dùng không được để trống");
            if (isNaN(userID)) throw new Error("ID người dùng không hợp lệ");
            var userInfo = await getInfo(userID);
            if (usersData.hasOwnProperty(userID)) return false
            var data = {
                [userID]: {
                    userID: userID,
                    name: userInfo.name,
                    vanity: userInfo.vanity || userID,
                    gender: userInfo.gender,
                    isBirthday: userInfo.isBirthday,
                    money: 0,
                    exp: 0,
                    createTime: {
                        timestamp: Date.now()
                    },
                    data: {
                        timestamp: Date.now()
                    },
                    lastUpdate: Date.now()
                }
            }
            Object.assign(usersData, data);
            await saveData(usersData);
            if (callback && typeof callback == "function") callback(null, data);
            return data;
        } catch (error) {
            if (callback && typeof callback == "function") callback(error, null);
            return false
        }
    }

    return {
        getInfo,
        getNameUser,
        getAll,
        getData,
        setData,
        delData,
        createData,
        getUserFull
    };
};