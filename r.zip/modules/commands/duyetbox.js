module.exports.config = {
  name: "duyetbox",
  version: "1.0.2",
  hasPermssion: 3,
  credits: "DungUwU",
  description: "duyệt box dùng bot xD",
  commandCategory: "Người hỗ trợ bot",
  cooldowns: 5
};
  
  
const dataPath = __dirname + "/cache/approvedThreads.json";
const pendingPath = __dirname + "/cache/pendingdThreads.json";
const onPath = __dirname + "/cache/on.json";
const fs = require("fs");

module.exports.onLoad = () => {
    if (!fs.existsSync(dataPath)) fs.writeFileSync(dataPath, JSON.stringify([]));
    if (!fs.existsSync(pendingPath)) fs.writeFileSync(pendingPath, JSON.stringify([]));
    if (!fs.existsSync(onPath)) fs.writeFileSync(onPath, JSON.stringify({ uwu : false }, null, 4));
}

module.exports.run = async ({ event, api, args }) => {
    const { threadID, messageID, senderID } = event;
    const moment = require("moment-timezone");
      var timeNow = moment.tz("Asia/Ho_Chi_Minh").format("DD/MM/YYYY || HH:mm:s");
    let data = JSON.parse(fs.readFileSync(dataPath));
    let pending = JSON.parse(fs.readFileSync(pendingPath));
    let on = JSON.parse(fs.readFileSync(onPath));
    let msg = "";
    let idBox = (args[0]) ? args[0] : threadID;
    if (args[0] == "list") {
      msg = "◉ ᴅᴀɴʜ sᴀ́ᴄʜ ʙᴏx :";
      let count = 0;
      for (e of data) {
        msg += `\n${count += 1} │ ${e}.com`;
      }
      api.sendMessage(msg, threadID, messageID);
    }
    else if (args[0] == "del") {
      let threadInfo = await api.getThreadInfo(event.threadID);
    let threadName = threadInfo.threadName;
      idBox = (args[1]) ? args[1] : event.threadID;
      if (isNaN(parseInt(idBox))) return api.sendMessage("◉ ᴋʜᴏ̂ɴɢ ᴘʜᴀ̉ɪ ᴍᴏ̣̂ᴛ ᴄᴏɴ sᴏ̂́", threadID, messageID);
      if (!data.includes(idBox)) return api.sendMessage("◉ ʙᴏx ɴᴀ̀ʏ ᴄʜᴜ̛ᴀ ᴅᴜʏᴇ̣̂ᴛ!", threadID, messageID);
      api.sendMessage(`◉ ʙᴏx : ${threadName}\n◉ ɪᴅ: ${idBox}\n◉ ʙɪ̣ ɢᴏ̛̃ ᴋʜᴏ̉ɪ ᴅᴀɴʜ sᴀ́ᴄʜ ᴅᴜ̀ɴɢ ʙᴏᴛ\n◉ ᴛɪᴍᴇ : ${timeNow} `, threadID, () => {
        if (!pending.includes(idBox)) pending.push(idBox);
        data.splice(data.indexOf(idBox), 1);
        fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
        fs.writeFileSync(pendingPath, JSON.stringify(pending, null, 2));
      }, messageID)
    }
    else if (args[0] == "pending") {
      
      msg = " ◉ ʟɪsᴛ ʙᴏx ᴄʜᴏ̛̀ ᴅʏᴇ̣̂ᴛ!";
      let count = 0;
      for (e of pending) {
        let name = (await api.getThreadInfo(e)).name || "Nhóm Chat";
        msg += `\n${count + 1} │ ${name} │ ${e}.com`;
        count++;
      }
      if(count == 0) msg = "◉ ᴋʜᴏ̂ɴɢ ᴄᴏ́";
      api.sendMessage(msg, threadID, messageID);
    } else if (args[0] == "on") {
      on.uwu = true;
      fs.writeFileSync(onPath, JSON.stringify(on, null, 4));
      api.sendMessage("◉ ʙᴀ̣̂ᴛ ᴅᴜʏᴇᴛʙᴏx.\n◉ ɴʜᴜ̛̃ɴɢ ɴʜᴏ́ᴍ ᴄʜᴜ̛ᴀ ᴅᴜʏᴇ̣̂ᴛ ᴋʜᴏ̂ɴɢ ᴛʜᴇ̂̉ sᴜ̛̉ ᴅᴜ̣ɴɢ ʙᴏᴛ ", threadID, messageID);
    } else if (args[0] == "off") {
      on.uwu = false;
      fs.writeFileSync(onPath, JSON.stringify(on, null, 4));
      api.sendMessage("◉ ᴛᴀ̆́ᴛ ᴅᴜʏᴇᴛʙᴏx.\n◉ ᴛᴀ̂́ᴛ ᴄᴀ̉ ʙᴏx ᴄᴏ́ ᴛʜᴇ̂̉ sᴜ̛̉ ᴅᴜ̣ɴɢ ʙᴏᴛ", threadID, messageID);
    }
    else if (isNaN(parseInt(idBox))) api.sendMessage("◉ ɪᴅ ʙᴀ̣ɴ ɴʜᴀ̣̂ᴘ ᴋʜᴏ̂ɴɢ ʜᴏ̛̣ᴘ ʟᴇ̣̂", threadID, messageID);
    else if (data.includes(idBox)) api.sendMessage(`◉ ɪᴅ ${idBox} ᴘʜᴇ̂ ᴅᴜʏᴇ̣̂ᴛ ᴛᴜ̛̀ ᴛʀᴜ̛ᴏ̛́ᴄ ʀᴏ̂̀ɪ!`, threadID, messageID);
    else api.sendMessage("「 ᴅᴜʏᴇ̣̂ᴛ ʙᴏx 」\n──── ･ ｡ﾟ☆: *.☽ .* :☆ﾟ. ────\n[❤] ᴀᴅᴍɪɴ ᴠᴜ̛̀ᴀ ᴅᴜʏᴇ̣̂ᴛ ʙᴏx ᴄᴜ̉ᴀ ʙᴀ̣ɴ\n[👀] ᴘʀᴇғɪx ᴄᴜ̉ᴀ ʙᴏᴛ ʟᴀ̀ !  \n──── ･ ｡ﾟ☆: *.☽ .* :☆ﾟ. ────\n[📌] ᴍᴏ̣ɪ ᴛʜᴀ̆́ᴄ ᴍᴀ̆́ᴄ ʟɪᴇ̂ɴ ʜᴇ̣̂ : https://www.facebook.com/100092178885052", idBox, (error, info) => {
      if (error) return api.sendMessage("◉ ʟᴏ̂̃ɪ ʀᴏ̂̀ɪ ", threadID, messageID);
      else {
        data.push(idBox);
        pending.splice(pending.indexOf(idBox), 1);
        fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
        fs.writeFileSync(pendingPath, JSON.stringify(pending, null, 2));
        api.sendMessage(``, threadID, messageID);
      }
    });
        }