module.exports.config = {
    name: "taixiu",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "D-Jukie",
    description: "ɢᴀᴍᴇ ᴛᴀ̀ɪ xɪ̉ᴜ ᴏɴʟɪɴᴇ",
    commandCategory: "Giải Trí",
    usages: "◉ !ᴛᴀɪxɪᴜ ( ᴛᴀ̀ɪ/xɪ̉ᴜ ) ( sᴏ̂́ ᴛɪᴇ̂̀ɴ )",
    cooldowns: 15
};
module.exports.run = async function ({ api, event, args, Currencies, Users }) {
    const { senderID, messageID, threadID } = event;
    const axios = require('axios');
    const fs = require("fs-extra");
    const dataMoney = await Currencies.getData(senderID);
    const moneyUser = dataMoney.money;
    if (!args[0]) return api.sendMessage("◉ ʙᴀ̣ɴ ᴘʜᴀ̉ɪ ᴄᴜ̛ᴏ̛̣ᴄ ᴛᴀ̀ɪ ʜᴏᴀ̣̆ᴄ xɪ̉ᴜ...", threadID, messageID);
    const choose = args[0]
    if (choose.toLowerCase() != 'tài' && choose.toLowerCase() != 'xỉu') return api.sendMessage("◉ ᴄʜɪ̉ đᴀ̣̆ᴛ ᴄᴜ̛ᴏ̛̣ᴄ ᴛᴀ̀ɪ ʜᴏᴀ̣̆ᴄ xɪ̉ᴜ", threadID, messageID)
    const money = args[1]
    if (money < 0 || isNaN(money)) return api.sendMessage("◉ ᴍᴜ̛́ᴄ ᴄᴜ̛ᴏ̛̣ᴄ ᴄᴜ̉ᴀ ʙᴀ̣ɴ ᴋʜᴏ̂ɴɢ ᴘʜᴜ̀ ʜᴏ̛̣ᴘ ʜᴏᴀ̣̆ᴄ ᴅᴜ̛ᴏ̛́ɪ 0", threadID, messageID);
    if (moneyUser < money) return api.sendMessage(`◉ ʙᴀ̣ɴ ᴛʜɪᴇ̂́ᴜ ᴛɪᴇ̂̀ɴ ʀᴏ̂̀ɪ`, threadID, messageID);
    try {
        const res = (await axios.get(`https://api-dien-1.hianime.repl.co/taixiu`)).data
        const image = [];
        const result = res.result;
        if(result == false) result = '3 mặt cùng loại';
        for (let i in res.images) {
            var path = __dirname + `/cache/${i}.png`;
            var img = (await axios.get(`${res.images[i]}`, { responseType: "arraybuffer" })).data;
            fs.writeFileSync(path, Buffer.from(img, "utf-8"));
            image.push(fs.createReadStream(path));
        }
        if (choose.toLowerCase() == result) {
            await Currencies.increaseMoney(senderID, parseInt(money * 1));
            api.sendMessage({ body: `[😀] ᴋᴇ̂́ᴛ ǫᴜᴀ̉: ${result}\n[💰] ʙᴀ̣ɴ ᴛʜᴀ̆́ɴɢ ᴠᴀ̀ ɴʜᴀ̣̂ɴ : ${money*1}$\n[💵] sᴏ̂́ ᴅᴜ̛ ʜɪᴇ̣̂ɴ ᴛᴀ̣ɪ: ${[moneyUser + money*1]}$`, attachment: image }, threadID, messageID);
        } else {
            await Currencies.decreaseMoney(senderID, parseInt(money));
            api.sendMessage({ body: `[🙂] ᴋᴇ̂́ᴛ ǫᴜᴀ̉: ${result}\n[💸] ʙᴀ̣ɴ ʙɪ̣ ʙᴀʏ ᴍᴀ̂́ᴛ: ${money*1}$\n[💵] sᴏ̂́ ᴅᴜ̛ ʜɪᴇ̣̂ɴ ᴛᴀ̣ɪ: ${[moneyUser - money*1]}$`, attachment: image}, threadID, messageID);
        }
        for(var i = 0; i < image.length; i++) {
            fs.unlinkSync(__dirname + `/cache/${i}.png`);
        }
    } catch(e) {
        console.log(e);
        return api.sendMessage('◉ ʟᴏ̂̃ɪ ʀᴏ̂̀ɪ, ʟɪᴇ̂ɴ ʜᴇ̣̂ ᴀᴅᴍɪɴ ʙᴀ́ᴏ ʟᴏ̂̃ɪ', threadID, messageID);
    }
}