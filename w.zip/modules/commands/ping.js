module.exports.config = {
	name: "ping",
	version: "1.0.4",
	hasPermssion: 1,
	credits: "Mirai Team",
	description: "ᴛᴀɢ ᴍᴏ̣ɪ ɴɢᴜ̛ᴏ̛̀ɪ ᴛʀᴏɴɢ ʙᴏx",
	commandCategory: "Tiện Ích",
	usages: "◉ !ᴘɪɴɢ\n◉ !ᴘɪɴɢ ( ᴠᴀ̆ɴ ʙᴀ̉ɴ)",
	cooldowns: 5
};

module.exports.run = async function({ api, event, args }) {
	try {
		const botID = api.getCurrentUserID();
		const listUserID = event.participantIDs.filter(ID => ID != botID && ID != event.senderID);
		var body = (args.length != 0) ? args.join(" ") : " 「 PING 」\n──── ･ ｡ﾟ☆: *.☽ .* :☆ﾟ. ────\n ◉  ʙᴀ̣ɴ ʙɪ̣ ǫᴛᴠ ᴋɪᴄᴋ ᴋʜᴏ̉ɪ ɴʜᴏ́ᴍ :))", mentions = [], index = 0;
		
		for(const idUser of listUserID) {
			body = "‎" + body;
			mentions.push({ id: idUser, tag: "‎", fromIndex: index - 1 });
			index -= 1;
		}

		return api.sendMessage({ body, mentions }, event.threadID, event.messageID);

	}
	catch (e) { return console.log(e); }
}