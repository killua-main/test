module.exports.config = {
	name: "refresh",
	version: "0.0.1",
	hasPermssion: 0,
	credits: "Mirai Team",
	description: "ʟᴏᴀᴅ ʟᴀ̣ɪ ᴛᴏᴀ̀ɴ ʙᴏ̣̂ ᴛʜᴏ̂ɴɢ ᴛɪɴ ᴄᴜ̉ᴀ ɴʜᴏ́ᴍ",
	commandCategory: "Tiện Ích",
  usage: "◉ !refresh",
	cooldowns: 500
};

module.exports.run = async ({ event, api, Threads }) => {
    const threadInfo = await api.getThreadInfo(event.threadID);
	await Threads.setData(event.threadID, { name: threadInfo.name, threadInfo });
	global.data.threadInfo.set(parseInt(event.threadID), threadInfo);
    return api.sendMessage("[ʀᴇғʀᴇsʜ] Đᴀ̃ ʟᴏᴀᴅ ʟᴀ̣ɪ ᴛᴏᴀ̀ɴ ʙᴏ̣̂ ᴛʜᴏ̂ɴɢ ᴛɪɴ ʙᴏx", event.threadID, event.messageID);
}