module.exports.config = {
 name: "join",
 version: "1.0.0", 
 hasPermssion: 2,
 credits: "cherry",
 description: "ᴛʜᴀᴍ ɢɪᴀ ᴠᴀ̀ᴏ ᴄᴀ́ᴄ ʙᴏx ᴄᴏ́ ʙᴏᴛ",
 commandCategory: "Admin", 
 usages: "◉ !ᴊᴏɪɴ", 
 cooldowns: 0,
 dependencies: {
   "request": "",
   "fs-extra":"",
   "axios":""
}};
module.exports.handleReply = async ({ event, api, handleReply, Threads }) => {
    var { threadID, messageID, body, senderID } = event;
    var { threadList, author } = handleReply;
    if (senderID != author) return;
    api.unsendMessage(handleReply.messageID);
    if (!body || !parseInt(body)) return api.sendMessage('◉ ʜᴀ̃ʏ ᴄʜᴏ̣ɴ ᴍᴏ̣̂ᴛ sᴏ̂́ 🙂', threadID, messageID);
    if (!threadList[parseInt(body) - 1]) return api.sendMessage("◉ ᴄʜᴏ̣ɴ ᴋɪ̃ ʟᴀ̣ɪ ʜᴏ̣̂ ʙᴏ̂́ ᴍᴀ̀ʏ 🙂", threadID, messageID);
    else {
        try {
            var threadInfo = threadList[parseInt(body) - 1];
            var { participantIDs } = threadInfo;
            if (participantIDs.includes(senderID)) return api.sendMessage('◉ ᴄᴏ́ ᴛʀᴏɴɢ ʙᴏx ɴᴀ̀ʏ ʀᴏ̂̀ɪ ᴄᴏ̀ɴ :))', threadID, messageID);
            api.addUserToGroup(senderID, threadInfo.threadID, (e) => {
              if (e) api.sendMessage(`◉ ʟᴏ̂̃ɪ ʀᴏ̂̀ɪ : ${e.errorDescription}`, threadID, messageID);
              else api.sendMessage(`◉ ʙᴏᴛ ᴛʜᴇ̂ᴍ ʙᴀ̣ɴ ᴠᴀ̀ᴏ ɴʜᴏ́ᴍ ${threadInfo.name} ᴛʜᴀ̀ɴʜ ᴄᴏ̂ɴɢ, xᴇᴍ ᴏ̛̉ ᴍᴜ̣ᴄ ᴛɪɴ ɴʜᴀ̆́ɴ ᴄʜᴏ̛̀ ʜᴏᴀ̣̆ᴄ sᴘᴀᴍ`, threadID, messageID);
            });
        }
        catch (error) {
            return api.sendMessage(`◉ ʟᴏ̂̃ɪ ʀᴏ̂̀ɪ: ${error}`, threadID, messageID);
        }
    }
};

module.exports. run = async function({ api, event, Threads }) {
    var { threadID, messageID, senderID } = event;
    var allThreads = (await api.getThreadList(500, null, ["INBOX"])).filter(i => i.isGroup),
    msg = `[📜] ᴅᴀɴʜ sᴀ́ᴄʜ ᴄᴀ́ᴄ ʙᴏx ᴄᴏ́ ʙᴏᴛ:\n──── ･ ｡ﾟ☆: *.☽ .* :☆ﾟ. ────\n`,
    number = 0;
    for (var thread of allThreads) {
        number++;
        msg += `${number}︱ ${thread.name}\n`;
    }
    msg += `\n◉ ʀᴇᴘʟʏ ᴛɪɴ ɴʜᴀ̆́ɴ ɴᴀ̀ʏ ᴄʜᴏ̣ɴ sᴛᴛ ʙᴏx ʙᴀ̣ɴ ᴍᴜᴏ̂́ɴ ᴠᴀ̀ᴏ`;
    return api.sendMessage(msg, threadID, (error, info) => {
        global.client.handleReply.push({
            name: this.config. name,
            messageID: info.messageID,
            author: senderID,
            threadList: allThreads
       
        });
    }, messageID);
};